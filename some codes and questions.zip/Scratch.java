
public class Scratch {
   
    public static void main(String [] args){

     
       System.out.println(Boolean_stmt());
    }
      public static boolean Boolean_stmt(){
        
        boolean a,b,c,d;
        d = !(2 > 4+3);
        b = !(3 > 2); // b is false
        c = !(2 > 3); // c is true
        a = d || c && b ; // d is false
       return a;
      }
       
      

          


    }

