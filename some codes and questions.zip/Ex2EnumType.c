#include<stdio.h>

enum EnumType{

one = 1, two = 2,three= 3,four = 4,five = 5,

};

int main (){

enum colorSet{red,blue,black,green,white}; //default values 0,1,2,3,4 respectively assigned to colors
enum  colorSet color ;
color = red; 
color = blue;
color = black;
color = green;
color = white;

printf("red is assigned to number %d\n",red);
printf("blue is assigned to number %d\n",blue);
printf("black is assigned to number %d\n",black);
printf("green is assigned to number %d\n",green);
printf("white is assigned to number %d\n",white);

int add = one+red,
 sub = two - blue,
 mul = three * black,
 div = four / green,
 rem = five % white,
 xor = one ^ blue,
 and = two & black,
 or = three | green,
 shiftRight = four >> white,
 shiftLeft = five << blue;

printf("Operation results on same line : ");
printf("%d ",add);
printf("%d ",sub);
printf("%d ",mul);
printf("%d ",div);
printf("%d ",rem);
printf("%d ",xor);
printf("%d ",and);
printf("%d ",or);
printf("%d ",shiftRight);
printf("%d ",shiftLeft);
return 0;
}