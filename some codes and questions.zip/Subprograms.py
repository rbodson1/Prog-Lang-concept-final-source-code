
def sub1():
    a=5
    b=5
    c=a+b
    print(c)


def sub2():
    sub1() #sub1 called by sub2
    b=10
    c=10
    d=b+c

    print(d)


def sub3():
    sub2() # sub2 called by sub3
    c=15
    d=15
    e=c+d

    print(e)


if __name__ == '__main__':
    sub3() #sub3 called by main