function func(){
  var a,b,c;
    a=10;
    b=5;
    c=a+b;
    console.log(c);
      
       function func1(){
        var d;
          d = b+c;
          console.log(d);

             function func2(){
               var e;
               e=c+d;
               console.log(e);



            }
           func2(); // called by func1

       }
       func1(); //called by func
    }
    func();