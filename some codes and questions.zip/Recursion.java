import java.util.*;
public class Recursion{ //simple calculator

   public static void main(String[] args){
      System.out.print("Enter an operation: ");
      Scanner sc = new Scanner(System.in);
   
      while(sc.hasNext()){
      
         int opnd1 = sc.nextInt();
         char sign = sc.next().charAt(0);
         int opnd2 = sc.nextInt();
               
         
      
         
         if(sign == '+'){
            int sum = opnd1 + opnd2;
            System.out.println("result = : "+sum);     
         
         } else if(sign == '-'){
            int difference = opnd1 - opnd2;
         
            System.out.println("result = : "+difference); 
         
         } else if(sign == '*'){
         
            int product = opnd1 * opnd2;
            System.out.println("result = : "+product);
            
         } else if(sign == '/'){
           
           int quotient = opnd1 / opnd2;
           int remainder = opnd1 % opnd2;
           System.out.print("result = "+quotient+"\nremainder = "+remainder);
         
         }
      }
   }
}
   
   









