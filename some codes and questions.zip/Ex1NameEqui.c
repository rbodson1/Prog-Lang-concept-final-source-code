#include<stdio.h>

struct Fruit1{
  int id;
  int quantity;
  double price;

};

struct Fruit2{
  int id;
  int quantity;
  double price;

};

int main(){
struct Fruit1 orange, apple;

 
orange.id =12;
orange.quantity = 2;
orange.price = 2.99;

apple = orange; // name equivalent because apple and orange are of the same name(Fruit1)

printf("%d\n",apple.id);
printf("%d\n",apple.quantity);
printf("$%.2f\n",apple.price);

}