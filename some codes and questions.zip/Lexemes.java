import java.io.*;
import java.util.*;

public class Lexemes {
   public static void main(String[] args) throws IOException {
      BufferedReader br = new BufferedReader(new FileReader("Text.txt"));
      String word = br.readLine();
      String characters=" :;<=>?@[]^_`{|}!#$%&'()*+,-./";
      while(word != null) {
         String[] separate = word.split(" ");
         for(int i = 0 ; i < separate.length ; i++) {
            String lexeme = separate[i];
            int count = 0;
            while(count < lexeme.length()) {
               if(characters.contains(Character.toString(lexeme.charAt(count)))) {
                  if(!characters.contains(Character.toString(lexeme.charAt(count-1)))){
                     System.out.println();
                  }
                  System.out.println(lexeme.charAt(count));
               }
               else {
                  System.out.print(lexeme.charAt(count));
               
               }
               count++;
            }
            System.out.println();
         }
         word = br.readLine(); 
      } 
   
   }

}
