#include <stdio.h>

int main (){

int arr[4][3];

for(int i=0;i<4;i++){
   for(int j=0;j<3;j++){
       printf("insert the value for arr[%d][%d]:",i,j);
       scanf("%d", &arr[i][j]);
   }


}
    for(int k=0;k<4;k++){
   for(int l=0;l<3;l++){
       printf("%d",arr[k][l]);
       
   }
printf("\n");

}
}





