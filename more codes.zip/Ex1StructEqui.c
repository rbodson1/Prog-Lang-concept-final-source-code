#include<stdio.h>

int main(){

int appleCount[5]={1,2,3,4,5};

int orangeCount[6]={6,7,8,9,10,11};

for(int i=0;i<5;i++){

    orangeCount[i]=appleCount[i]; // structure equivalent because orangeCount and appleCount are of the same type structure
}

for(int i=0;i<6;i++){

printf("%d\n",orangeCount[i]);

}

}