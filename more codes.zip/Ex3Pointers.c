#include<stdio.h> 
#include<stdlib.h>

int main (){

int *arr=(int*)malloc(3 * 2 * sizeof(int));

int val;

for(int i=0;i<4;i++){
   for(int j=0;j<3;j++){
       printf("insert the value for arr[%d][%d]:",i,j);
       scanf("%d", &val);

       *(arr+i*2+j)=val;
   }


}
    for(int k=0;k<4;k++){
   for(int l=0;l<3;l++){
       printf("%d",*(arr+k*2+l));
       
   }
printf("\n");

}
}





